#!/bin/bash
IFS=","
while read f1 f2
do
echo "rename from : $f1"
echo "to : $f2"
mv $f1 "$f2"
echo "done"
done < segaclassicslist.csv
